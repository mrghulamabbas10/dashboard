import PairExplorer from '@/components/PairExplorer'

export default function Home() {
  return <PairExplorer />
}
